@push('script')
    <script>
        function heroMain() {
            return {
                profile: {},
                init() {
                    this.profile = Alpine.store('profileStore').profile;

                }
            }
        }
    </script>
@endpush

<div id="home" class=" section sofax-section-padding4">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="sofax-hero-content hero-v8 mx-3">
                    <h1 class="slider-custom-anim-left" data-ani="slider-custom-anim-left" data-ani-delay="0.3s">
                        Solusi Estetika & Keamanan untuk Hunian Modern!</h1>
                    <p>Kaca film premium kami meningkatkan estetika dan keamanan hunian modern dengan mengurangi panas,
                        silau, dan melindungi dari sinar UV</p>
                    <div class="sofax-hero-btn-wrap sofax-hero5-btn extra-mt">
                        <a class="sofax-default-btn pill dark-btn wow fadeInUpX" data-wow-delay="0.20s"
                            data-text="Contact Us" href="">
                            <span class="button-wraper">Contact Us</span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="sofax-hero-thumb8 wow fadeInUpX position-ralatiove">
                    <img src="{{ asset('image/WhatsApp Image 2025-02-18 at 12.06.24_46f0ff3f.jpg') }}" alt=""
                        height="600px">
                    <div class="sofax-hero-shape-v8">
                        <img src="{{ asset('image/WhatsApp Image 2025-02-18 at 12.06.24_109c4eaa.jpg') }}"
                            alt="" height="400px">
                    </div>
                    <div class="sofax-hero-shape2-v8">
                        <img src="{{ asset('image/WhatsApp Image 2025-02-18 at 12.06.24_0e2c56fe.jpg') }}"
                            alt="" height="400px">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
