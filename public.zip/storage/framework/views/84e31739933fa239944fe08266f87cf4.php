<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['heroPortfolio'=>null]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['heroPortfolio'=>null]); ?>
<?php foreach (array_filter((['heroPortfolio'=>null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
    <section class="sofax-section-padding2">
        <div class="container">
            <div class="sofax-section-title center">
                <div class="tg-heading-subheading animation-style3">
                    <h2>Our Portfolio</h2>
                </div>
            </div>
        </div>
        <div class="sofax-testimonial-slider">
            <?php $__currentLoopData = $heroPortfolio['hero_image']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="sofax-testimonial-content">
                <div class="card text-center p-3">
                        <img src="<?php echo e('https://api.apexhub.id/assets/'.$item['image']); ?>" class="img-fluid rounded mb-3" alt="Derrick Turner" style="max-width: 400px;">
                        <h5 class="card-title"><?php echo e($item['name']); ?></h5>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="sofax-testimonial-slider-2">
            <?php $__currentLoopData = $heroPortfolio['hero_image']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="sofax-testimonial-content">
                <div class="card text-center p-3">
                        <img src="<?php echo e('https://api.apexhub.id/assets/'.$item['image']); ?>" class="img-fluid rounded mb-3" alt="Derrick Turner" style="max-width: 400px;">
                        <h5 class="card-title"><?php echo e($item['name']); ?></h5>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </section>
<?php /**PATH C:\projeck\bali promotion\pasang-kaca-film\resources\views/components/our-portfolio/index.blade.php ENDPATH**/ ?>