
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php if (isset($component)) { $__componentOriginal8593843869bbb19629c78ecf5fddccfb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8593843869bbb19629c78ecf5fddccfb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.navbar.index','data' => ['profile' => $profileHero]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('navbar.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['profile' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($profileHero)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8593843869bbb19629c78ecf5fddccfb)): ?>
<?php $attributes = $__attributesOriginal8593843869bbb19629c78ecf5fddccfb; ?>
<?php unset($__attributesOriginal8593843869bbb19629c78ecf5fddccfb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8593843869bbb19629c78ecf5fddccfb)): ?>
<?php $component = $__componentOriginal8593843869bbb19629c78ecf5fddccfb; ?>
<?php unset($__componentOriginal8593843869bbb19629c78ecf5fddccfb); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal76fe3a7e61428ddabddbc31480dd5f0f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76fe3a7e61428ddabddbc31480dd5f0f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.main-hero.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('main-hero.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76fe3a7e61428ddabddbc31480dd5f0f)): ?>
<?php $attributes = $__attributesOriginal76fe3a7e61428ddabddbc31480dd5f0f; ?>
<?php unset($__attributesOriginal76fe3a7e61428ddabddbc31480dd5f0f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76fe3a7e61428ddabddbc31480dd5f0f)): ?>
<?php $component = $__componentOriginal76fe3a7e61428ddabddbc31480dd5f0f; ?>
<?php unset($__componentOriginal76fe3a7e61428ddabddbc31480dd5f0f); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal7b362d4599f26a1848da47ead772a380 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7b362d4599f26a1848da47ead772a380 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.our-service-hero.index','data' => ['heroOutservice' => $heroOutservice]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('our-service-hero.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heroOutservice' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($heroOutservice)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7b362d4599f26a1848da47ead772a380)): ?>
<?php $attributes = $__attributesOriginal7b362d4599f26a1848da47ead772a380; ?>
<?php unset($__attributesOriginal7b362d4599f26a1848da47ead772a380); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b362d4599f26a1848da47ead772a380)): ?>
<?php $component = $__componentOriginal7b362d4599f26a1848da47ead772a380; ?>
<?php unset($__componentOriginal7b362d4599f26a1848da47ead772a380); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal06d48785f5d07e48d90a3705a60004c2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06d48785f5d07e48d90a3705a60004c2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.our-portfolio.index','data' => ['heroPortfolio' => $heroPortfolio]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('our-portfolio.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heroPortfolio' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($heroPortfolio)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06d48785f5d07e48d90a3705a60004c2)): ?>
<?php $attributes = $__attributesOriginal06d48785f5d07e48d90a3705a60004c2; ?>
<?php unset($__attributesOriginal06d48785f5d07e48d90a3705a60004c2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06d48785f5d07e48d90a3705a60004c2)): ?>
<?php $component = $__componentOriginal06d48785f5d07e48d90a3705a60004c2; ?>
<?php unset($__componentOriginal06d48785f5d07e48d90a3705a60004c2); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal2f9a0a5c371203ed742c9e43a395e7d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f9a0a5c371203ed742c9e43a395e7d6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.about-us.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('about-us.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f9a0a5c371203ed742c9e43a395e7d6)): ?>
<?php $attributes = $__attributesOriginal2f9a0a5c371203ed742c9e43a395e7d6; ?>
<?php unset($__attributesOriginal2f9a0a5c371203ed742c9e43a395e7d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f9a0a5c371203ed742c9e43a395e7d6)): ?>
<?php $component = $__componentOriginal2f9a0a5c371203ed742c9e43a395e7d6; ?>
<?php unset($__componentOriginal2f9a0a5c371203ed742c9e43a395e7d6); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalb9db8c80136f0dc1b2e03adf352f76ee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb9db8c80136f0dc1b2e03adf352f76ee = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footer.index'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb9db8c80136f0dc1b2e03adf352f76ee)): ?>
<?php $attributes = $__attributesOriginalb9db8c80136f0dc1b2e03adf352f76ee; ?>
<?php unset($__attributesOriginalb9db8c80136f0dc1b2e03adf352f76ee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb9db8c80136f0dc1b2e03adf352f76ee)): ?>
<?php $component = $__componentOriginalb9db8c80136f0dc1b2e03adf352f76ee; ?>
<?php unset($__componentOriginalb9db8c80136f0dc1b2e03adf352f76ee); ?>
<?php endif; ?>


    <a href="https://api.whatsapp.com/send?phone=<?php echo e($profileHero->tlp ?? ''); ?>&text=<?php echo e(urlencode('Halo mau menjadi mitra Balihooo')); ?>"
        target="_blank" class="whatsapp-button" title="Chat via WhatsApp">
        <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" alt="WhatsApp Icon">
    </a>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\projeck\bali promotion\pasang-kaca-film\resources\views/pages/home.blade.php ENDPATH**/ ?>