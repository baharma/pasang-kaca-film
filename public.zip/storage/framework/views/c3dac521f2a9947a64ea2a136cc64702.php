<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['profile'=>null]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['profile'=>null]); ?>
<?php foreach (array_filter((['profile'=>null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<header class="site-header sofax-header-section site-header--menu-center" id="sticky-menu">
    <div class="container" x-data="navbarComponent()">
        <nav class="navbar site-navbar">
            <!-- Brand Logo-->
            <div class="brand-logo">
                <a href="/" class="lead fw-bolder" style="text-decoration: none;color:brown;">
                    <img src="<?php echo e(asset('image/Logo Pasangkacafilm.webp')); ?>" alt="">
                </a>
            </div>
            <div class="menu-block-wrapper">
                <div class="menu-overlay"></div>
                <nav class="menu-block" id="append-menu-header">
                    <div class="mobile-menu-head">
                        <div class="go-back">
                            <i class="fa fa-angle-left"></i>
                        </div>
                        <div class="current-menu-title"></div>
                        <div class="mobile-menu-close">&times;</div>
                    </div>
                    <ul class="site-menu-main">

                        <li class="nav-item">
                            <a href="#home" class="nav-link-item">Home</a>
                        </li>
                        <li class="nav-item">
                            <a href="#service" class="nav-link-item">Service</a>
                        </li>
                        <li class="nav-item">
                            <a href="#portfolio" class="nav-link-item">Portfolio</a>
                        </li>
                        <li class="nav-item">
                            <a href="#blog" class="nav-link-item">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a href="#testimonial" class="nav-link-item">Blog</a>
                        </li>
                    </ul>
                </nav>
            </div>

            <div class="header-btn header-three-site-btn header-btn-l1 ms-auto d-none d-xs-inline-flex">
                <a class="sofax-default-btn pill sofax-header-btn" data-text="Get started" href="https://api.whatsapp.com/send?phone=<?php echo e($profile->tlp ?? ''); ?>&text=<?php echo e(urlencode('Saya Mau pasang kaca film')); ?>">
                    <span class="button-wraper">Contact Us</span>
                </a>
            </div>
            <!-- mobile menu trigger -->
            <div class="mobile-menu-trigger ">
                <span></span>
            </div>
            <!--/.Mobile Menu Hamburger Ends-->
        </nav>
    </div>
</header>
<!--End landex-header-section -->
<?php /**PATH C:\projeck\bali promotion\pasang-kaca-film\resources\views/components/navbar/index.blade.php ENDPATH**/ ?>