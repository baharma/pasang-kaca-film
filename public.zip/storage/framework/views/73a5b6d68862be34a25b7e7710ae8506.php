<div class="sofax-hero-section overflow-hidden">
    <div class="container">
        <div class="sofax-hero-content center">
            <h1 class="slider-custom-anim-left" data-ani="slider-custom-anim-left" data-ani-delay="0.3s">About Us</h1>
            <p>Selamat datang di pasangskacastiker.com! Kami adalah solusi terpercaya untuk pemasangan kaca sticker
                berkualitas tinggi yang menggabungkan keindahan estetika dengan fungsi perlindungan. Dengan pengalaman
                dan dedikasi, tim kami berkomitmen memberikan pelayanan profesional serta inovasi terbaru untuk menjawab
                kebutuhan desain dan keamanan hunian maupun ruang komersial Anda.

                Di pasangskacastiker.com, kepuasan pelanggan adalah prioritas utama. Kami percaya bahwa setiap
                pemasangan kaca sticker bukan hanya tentang tampilan yang menarik, tetapi juga menciptakan nilai tambah
                yang berkelanjutan bagi lingkungan Anda. Bergabunglah dengan kami untuk mewujudkan ruangan yang lebih
                modern, nyaman, dan penuh gaya!
                .
            </p>
        </div>
        <div class="sofax-subscription-field blog-details-subscribe-btn sofax-rating-icon">
        </div>
        <div class="sofax-hero-thumb1 wow fadeInUpX">
            <div class="sofax-hero-shape2">
                <img src="assets/images/v1/shape2.png" alt="">
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\projeck\bali promotion\pasang-kaca-film\resources\views/components/about-us/index.blade.php ENDPATH**/ ?>